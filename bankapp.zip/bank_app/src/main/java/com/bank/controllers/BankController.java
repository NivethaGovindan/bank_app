package com.bank.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.service.ICustomerlistService;
import com.bank.models.Customer;

@RestController
public class BankController {
	
	
	@Autowired
	ICustomerlistService customerService;
	
	@GetMapping(value = "/hello")
	public String hello(){
		return "hello";
	}

	
	@GetMapping(value = "/list")
	public List<Customer> list(){
		System.out.println("ist called");
		return customerService.list();
	}
	
	@GetMapping(value = "/create")
	public int createName(@RequestParam String name) {
		return customerService.createAccount(name);
	}
	
	@GetMapping(value = "/deposit")
	public String putDeposit(@RequestParam int id, @RequestParam int amount ) {
		return customerService.deposit(id, amount);
	}
	
	@GetMapping(value = "/balance")
	public int getBalance(@RequestParam String id) {
		return customerService.getBalance(Integer.parseInt(id));
	}
	
	@GetMapping(value = "/withdraw")
	public String withdraw(@RequestParam int id, @RequestParam int amount ) {
		return customerService.withdraw(id, amount);
	}
	

}

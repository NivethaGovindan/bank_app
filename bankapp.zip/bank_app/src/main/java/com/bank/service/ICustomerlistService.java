package com.bank.service;

import java.util.List;
import com.bank.models.Customer;

public interface ICustomerlistService {
	
	public List<Customer> list();
	public int getBalance(int id);
	public int createAccount(String name);
	public String deposit(int id, int amount);
	public String withdraw(int id, int amount);
};

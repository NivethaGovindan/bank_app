package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bank.models.Customer;
import com.bank.repositories.CustomerRepository;
import org.springframework.stereotype.Service;

@Service
public class CustomerlistServiceImpl implements ICustomerlistService{
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public List<Customer> list(){
		return customerRepository.findAll();
	}
	
	@Override
	public int getBalance(int id) {
		
		Customer customer = customerRepository.findByAccountId(id);
		return customer.getBalance();
	}
	
	@Override
	public int createAccount(String name) {
		 
		Customer customer = new Customer();
	    customer.setCustomerName(name);
	    customer.setBalance(0);
	    customerRepository.save(customer);
	     
	    return customer.getAccountId();
	 }
	
	@Override
	public String deposit(int id, int amount) {
		
		if(amount < 500) {
			return "Minimum deposit is 500";
		}
		else if(amount > 50000) {
			return "Maximum deposit is 50000";
		}
		 
		Customer customer = customerRepository.findByAccountId(id);
		int current_balance = customer.getBalance()+amount;
		
		if(current_balance > 100000) {
			
			return "balance cannot exceed 100000";
		}
		
	    customer.setBalance(current_balance);
	    customerRepository.save(customer);
	     
	    return Integer.toString(current_balance);
	 }
	
	@Override
	public String withdraw(int id, int amount) {
		
		if(amount < 1000) {
			return "Minimum withdrawal amount is 1000";
		}
		else if(amount > 25000) {
			return "Maximum withdrawal amount is 25000";
		}
		 
		Customer customer = customerRepository.findByAccountId(id);
		int current_balance = customer.getBalance()-amount;
		
		if(current_balance < 0) {
			
			return "Insufficient balance";
		}
		
	    customer.setBalance(current_balance);
	    customerRepository.save(customer);
	     
	    return Integer.toString(current_balance);
	 }

}
